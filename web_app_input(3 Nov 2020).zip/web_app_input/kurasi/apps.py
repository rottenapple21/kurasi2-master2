from django.apps import AppConfig


class KurasiConfig(AppConfig):
    name = 'kurasi'
