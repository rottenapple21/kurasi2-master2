from django_pika_pubsub import Producer

producer = Producer.get_producer()
producer.produce(
        body={'id': order.id},
        routing_key='order.sent.order_id.1.0.0'
)

#establish a connection using AMQP URL (in details)
url = os.environ.get('CLOUDAMQP_URL', 'amqps://qqhlybbt:FAWyUwEJ0dmIDuAYN_Wg_sC9zo3IIRVR@finch.rmq.cloudamqp.com/qqhlybbt')
params = pika.URLParameters(url)
connection = pika.BlockingConnection(params)
channel = connection.channel()

#make a queue named "hello" (to make sure the recipient queue exists)
channel.queue_declare(queue='hello')

#use a default exchange identify
channel.basic_publish(exchange='', routing_key='hello', body='Hello Subscriber!')

#make sure the message was delivered (print a message)
print(" [x] Sent to the consumers!")

#close the connection
connection.close()
