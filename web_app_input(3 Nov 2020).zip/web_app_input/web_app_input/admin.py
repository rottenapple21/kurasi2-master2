from django.contrib import admin
from .models import AddLink

# Register your models here.
admin.site.register(AddLink)
