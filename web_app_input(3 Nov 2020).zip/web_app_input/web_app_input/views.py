from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.shortcuts import render
from . import forms
from django.contrib import messages

def welcome(request):
    return render(request, 'welcome.html')

def addlink(request):
    form = forms.AddLinkForm()

    if request.method == 'POST':
        form = forms.AddLinkForm(request.POST)
        if form.is_valid():
            #kirim link ke database
            form.save()
            messages.success(request, 'Berhasil Kirim Link')
            return HttpResponseRedirect(reverse('addlink'))

    return render(request, 'addlink.html', {'form' : form})
