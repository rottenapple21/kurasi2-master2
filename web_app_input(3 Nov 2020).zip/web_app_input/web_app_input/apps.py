from django.apps import AppConfig


class webappinputConfig(AppConfig):
    name = 'web_app_input'
