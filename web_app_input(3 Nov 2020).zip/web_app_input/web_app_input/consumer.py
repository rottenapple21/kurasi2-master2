from django_pika_pubsub import MyConsumer

consumer = MyConsumer.get_consumer()
consumer.consume(
        routing_key='test',
        callback=callback,
)

def callback(channel, method, properties, body):
        payload = json.loads(body)
        order_id = payload.get('id')
        if order_id:
                print(f'{order_id=}')
